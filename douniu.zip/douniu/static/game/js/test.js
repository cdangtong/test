$(document).ready(function(){
   function test(){
    console.log("paiImage", paiImage[0]);
  }
  test();
})