<?php
namespace app\admin\controller;
use think\Db;
use think\Controller;
class Ad extends Common
{
	
}

