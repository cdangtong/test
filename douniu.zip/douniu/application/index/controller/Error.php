<?php 
namespace app\index\controller;
use think\Controller;
//用模型就不用引入
class Error
{
	public function _empty()
	{	
	    echo 'error';
	}

}
