<?php
namespace app\common\model;
use think\Model;
class Pay extends Model{
	
}