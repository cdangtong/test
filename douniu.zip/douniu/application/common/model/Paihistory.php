<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/7/22
 * Time: 9:39
 */
namespace app\common\model;
use think\Model;
class Paihistory extends Model{

}